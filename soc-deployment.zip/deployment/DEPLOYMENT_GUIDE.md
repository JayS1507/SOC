# SOC Platform — Deployment Guide (60-PC Lab)

## Overview

```
[60 Student PCs]  ──ethernet──►  [Core Switch]  ◄──  [SOC Server (teacher PC)]
  agent.py                                               manager.py  (port 9000)
  sends events                                           dashboard/  (port 8000)
                                                             ▲
                                                    [Instructor browser]
                                                    http://SERVER_IP:8000
```

---

## Step 0 — Edit lab.conf  ← DO THIS FIRST

Open `deployment/lab.conf` and set:

```bash
SERVER_IP="192.168.1.100"   # IP of the teacher/SOC machine
IP_PREFIX="192.168.1"       # Your lab subnet (first 3 octets)
IP_START=101                # Last octet of first student PC
IP_END=160                  # Last octet of last student PC
SSH_USER="student"          # Linux username on student PCs
SSH_PASS="lab@2024"         # Password (or leave "" for SSH keys)
```

To find your server IP: `hostname -I`

---

## Step 1 — Set up the server (teacher PC)

```bash
cd soc-platform/deployment
chmod +x *.sh
sudo ./1_setup_server.sh
```

This installs Python deps, opens ports 9000 and 8000, and starts
the manager + dashboard as systemd services (auto-start on boot).

**Check it worked:**
```bash
systemctl status soc-manager
systemctl status soc-dashboard
# Dashboard should be at: http://YOUR_SERVER_IP:8000
```

---

## Step 2 — Deploy agents to student PCs

### Option A: Mass deploy over SSH (recommended — all 60 at once)

**First time only** — push SSH keys so no passwords needed:
```bash
./0_setup_ssh_keys.sh
```

**Then deploy to all PCs:**
```bash
./3_deploy_all.sh
```

Retry any failed machines:
```bash
./3_deploy_all.sh --retry
```

---

### Option B: Manual install (USB + walk to each PC)

1. Copy the `soc-platform` folder to a USB drive
2. On each student PC, plug in USB and run:
```bash
cd /media/usb/soc-platform/deployment
sudo ./2_install_agent.sh
```
The script auto-detects the PC number from hostname or IP.
Or specify it manually: `sudo ./2_install_agent.sh 5`  (for PC-05)

---

## Step 3 — Verify everything is working

```bash
./4_check_status.sh
```

Or for a live auto-refreshing view:
```bash
watch -n 10 ./4_check_status.sh
```

All 60 agents should appear as **ONLINE** in the dashboard
within 30 seconds of the agent starting.

---

## File reference

| Script | Run on | Purpose |
|--------|--------|---------|
| `lab.conf` | — | All config settings. **Edit this first.** |
| `0_setup_ssh_keys.sh` | Server | Push SSH key to all 60 PCs (one-time) |
| `1_setup_server.sh` | Server | Install + start manager & dashboard |
| `2_install_agent.sh` | Each student PC | Install agent + shell hooks + systemd service |
| `3_deploy_all.sh` | Server | Deploy to all 60 PCs via SSH |
| `4_check_status.sh` | Server | Live status of all agents |
| `5_uninstall_agent.sh` | Student PC | Remove agent completely |

---

## Troubleshooting

**Agent shows OFFLINE on dashboard:**
```bash
# On the student PC:
systemctl status soc-agent
journalctl -u soc-agent -n 30
```

**Cannot connect to manager:**
```bash
# From student PC, test:
python3 -c "import socket; socket.create_connection(('SERVER_IP', 9000), 5)"
# If fails: check UFW on server: sudo ufw status
```

**Shell commands not appearing in dashboard:**
- Student must open a NEW terminal after agent install
- The hook is in `/etc/profile.d/soc_monitor.sh` (loaded on new shell)
- Check: `cat ~/.soc_cmd_log` on student PC

**Browser visits not showing:**
- Brave must have been opened at least once before agent starts
- Agent detects: `~/snap/brave/*/History`

**Database issues:**
```bash
# On server, restart everything cleanly:
sudo systemctl restart soc-manager soc-dashboard
```

---

## Useful commands (server)

```bash
# Restart services
sudo systemctl restart soc-manager soc-dashboard

# View manager logs live
journalctl -u soc-manager -f

# View dashboard logs live
journalctl -u soc-dashboard -f

# Check how many agents are connected
curl -s http://localhost:8000/api/agents | python3 -m json.tool

# Check alerts
curl -s "http://localhost:8000/api/alerts?limit=10" | python3 -m json.tool
```

## Useful commands (student PC)

```bash
# Check if agent is running
systemctl status soc-agent

# Watch agent logs live
journalctl -u soc-agent -f

# Manually restart agent
sudo systemctl restart soc-agent

# Check shell command log (what's being captured)
tail -f ~/.soc_cmd_log
```
