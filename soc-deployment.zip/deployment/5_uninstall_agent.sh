#!/bin/bash
# ============================================================
#  SOC Platform — UNINSTALL AGENT
#  Removes the agent from a student PC completely.
#  Run on the student PC (or called over SSH).
#
#  Usage:
#    sudo ./5_uninstall_agent.sh
# ============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
success() { echo -e "${GREEN}[OK]${NC} $1"; }
info()    { echo -e "[..] $1"; }
warn()    { echo -e "${YELLOW}[!!]${NC} $1"; }

[[ "$EUID" -ne 0 ]] && { echo "Run as root: sudo ./5_uninstall_agent.sh"; exit 1; }

echo ""
echo "  SOC Platform — Uninstalling agent..."
echo ""

# Stop + disable service
systemctl stop soc-agent    2>/dev/null && success "Service stopped"   || warn "Service not running"
systemctl disable soc-agent 2>/dev/null && success "Service disabled"  || true
rm -f /etc/systemd/system/soc-agent.service
systemctl daemon-reload

# Remove shell hooks
rm -f /etc/profile.d/soc_monitor.sh
success "System-wide shell hook removed"

# Remove hooks from user RC files
STUDENT_HOME=$(getent passwd "${SUDO_USER:-$USER}" | cut -d: -f6)
for RC in "$STUDENT_HOME/.bashrc" "$STUDENT_HOME/.zshrc"; do
    if [[ -f "$RC" ]]; then
        sed -i '/SOC_MONITOR_HOOK/,/^fi$/d' "$RC" 2>/dev/null || true
        success "Hook removed from $RC"
    fi
done

# Remove SOC cmd log
rm -f "$STUDENT_HOME/.soc_cmd_log"

# Remove agent_config.py
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
rm -f "$SOC_DIR/agent/agent_config.py"

success "Uninstall complete"
echo ""
