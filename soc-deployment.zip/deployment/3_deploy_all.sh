#!/bin/bash
# ============================================================
#  SOC Platform — MASS DEPLOYMENT over SSH
#  Deploys the agent to all 60 student PCs in one shot.
#  Run from the SERVER (teacher PC) after running:
#    1_setup_server.sh
#    0_setup_ssh_keys.sh   ← sets up passwordless SSH
#
#  Usage:
#    chmod +x 3_deploy_all.sh
#    ./3_deploy_all.sh
#
#  To retry failed PCs only:
#    ./3_deploy_all.sh --retry
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
source "$SCRIPT_DIR/lab.conf"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; GRAY='\033[0;37m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
fail()    { echo -e "${RED}[✗]${NC} $1"; }

RETRY_FILE="/tmp/soc_deploy_failed.txt"
RETRY_MODE=false
[[ "${1:-}" == "--retry" ]] && RETRY_MODE=true

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║     SOC PLATFORM — MASS DEPLOYMENT (60 PCs)     ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

SERVER_IP_LOCAL=$(hostname -I | awk '{print $1}')
info "Deploying from  : $SERVER_IP_LOCAL"
info "Manager IP      : $SERVER_IP:$MANAGER_PORT"
info "Target range    : ${IP_PREFIX}.${IP_START} → ${IP_PREFIX}.${IP_END}"
info "SSH user        : $SSH_USER"
info "Install path    : $AGENT_INSTALL_DIR"
[[ "$RETRY_MODE" == true ]] && info "Mode: RETRY failed machines only"
echo ""

# ── Preflight: install helpers ────────────────────────────────
if [[ -n "$SSH_PASS" ]] && ! command -v sshpass &>/dev/null; then
    info "Installing sshpass..."
    sudo apt-get install -y sshpass -q
fi
if ! command -v rsync &>/dev/null; then
    sudo apt-get install -y rsync -q
fi

read -p "  Start deployment? [y/N]: " go
[[ ! "$go" =~ ^[Yy] ]] && { echo "Aborted."; exit 0; }
echo ""

# ── SSH / rsync helpers ───────────────────────────────────────
SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=8 -o BatchMode=${SSH_PASS:+no}${SSH_PASS:-yes} -o LogLevel=ERROR"

ssh_cmd() {
    local ip="$1"; shift
    if [[ -n "$SSH_PASS" ]]; then
        sshpass -p "$SSH_PASS" ssh $SSH_OPTS "$SSH_USER@$ip" "$@"
    else
        ssh $SSH_OPTS "$SSH_USER@$ip" "$@"
    fi
}

rsync_to() {
    local ip="$1" src="$2" dst="$3"
    local rsync_ssh="ssh $SSH_OPTS"
    if [[ -n "$SSH_PASS" ]]; then
        sshpass -p "$SSH_PASS" rsync -az --delete -q -e "$rsync_ssh" "$src" "$SSH_USER@$ip:$dst"
    else
        rsync -az --delete -q -e "$rsync_ssh" "$src" "$SSH_USER@$ip:$dst"
    fi
}

# ── Deployment loop ───────────────────────────────────────────
TOTAL=$((IP_END - IP_START + 1))
PASS=0; FAIL=0; SKIP=0
FAILED_IPS=()

# Clear retry file at start of fresh run
[[ "$RETRY_MODE" == false ]] && rm -f "$RETRY_FILE"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
printf "  %-6s %-18s %-12s %s\n" "PC" "IP" "STATUS" "DETAIL"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for i in $(seq $IP_START $IP_END); do
    IP="${IP_PREFIX}.${i}"
    PC_NUM=$((i - IP_START + 1))
    PC_PAD=$(printf "%02d" "$PC_NUM")

    # In retry mode, skip PCs that succeeded before
    if [[ "$RETRY_MODE" == true ]] && ! grep -q "^$IP$" "$RETRY_FILE" 2>/dev/null; then
        continue
    fi

    printf "  PC-%02d  %-18s " "$PC_NUM" "$IP"

    # ── Step 1: Ping check ──
    if ! ping -c1 -W2 "$IP" &>/dev/null; then
        printf "${YELLOW}%-12s${NC} %s\n" "OFFLINE" "skipping"
        [[ "$RETRY_MODE" == false ]] && echo "$IP" >> "$RETRY_FILE"
        ((SKIP++))
        continue
    fi

    # ── Step 2: SSH connectivity check ──
    if ! ssh_cmd "$IP" "echo ok" &>/dev/null 2>&1; then
        printf "${RED}%-12s${NC} %s\n" "SSH FAIL" "check credentials"
        echo "$IP" >> "$RETRY_FILE"
        FAILED_IPS+=("PC-${PC_PAD} ($IP) — SSH failed")
        ((FAIL++))
        continue
    fi

    # ── Step 3: Rsync SOC platform folder ──
    if ! rsync_to "$IP" "$SOC_DIR/" "$AGENT_INSTALL_DIR/" 2>/dev/null; then
        printf "${RED}%-12s${NC} %s\n" "RSYNC FAIL" "check disk space"
        echo "$IP" >> "$RETRY_FILE"
        FAILED_IPS+=("PC-${PC_PAD} ($IP) — rsync failed")
        ((FAIL++))
        continue
    fi

    # ── Step 4: Run installer over SSH ──
    INSTALL_CMD="sudo $AGENT_INSTALL_DIR/deployment/2_install_agent.sh $PC_NUM"
    INSTALL_LOG=$(ssh_cmd "$IP" "$INSTALL_CMD" 2>&1)
    if [[ $? -ne 0 ]]; then
        printf "${RED}%-12s${NC} %s\n" "INSTALL FAIL" "see log below"
        echo "$IP" >> "$RETRY_FILE"
        FAILED_IPS+=("PC-${PC_PAD} ($IP) — install failed")
        # Show last few lines of error
        echo "$INSTALL_LOG" | tail -3 | sed 's/^/    /'
        ((FAIL++))
        continue
    fi

    printf "${GREEN}%-12s${NC} agent-%s ready\n" "DEPLOYED" "$PC_PAD"
    ((PASS++))
done

# ── Summary ───────────────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "  ${GREEN}✅ Deployed : $PASS / $TOTAL${NC}"
echo -e "  ${YELLOW}⏭  Offline  : $SKIP${NC} (will auto-connect when they boot)"
echo -e "  ${RED}❌ Failed   : $FAIL${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [[ ${#FAILED_IPS[@]} -gt 0 ]]; then
    echo ""
    warn "Failed machines:"
    for m in "${FAILED_IPS[@]}"; do echo "    $m"; done
    echo ""
    echo "  Retry:  ./3_deploy_all.sh --retry"
fi

echo ""
echo -e "  Dashboard: ${GREEN}http://$SERVER_IP:$DASHBOARD_PORT${NC}"
echo "  Deployed agents appear within 30 seconds."
echo ""
