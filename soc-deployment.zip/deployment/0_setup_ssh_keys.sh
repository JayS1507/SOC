#!/bin/bash
# ============================================================
#  SOC Platform — SSH KEY SETUP  (run this FIRST, optional)
#  Pushes your SSH key to all 60 student PCs so that
#  3_deploy_all.sh works without typing passwords.
#
#  Run on the SERVER (teacher PC):
#    chmod +x 0_setup_ssh_keys.sh
#    ./0_setup_ssh_keys.sh
# ============================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lab.conf"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║     SOC PLATFORM — SSH KEY DISTRIBUTION          ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  This pushes your SSH public key to all lab PCs"
echo "  so future scripts run without password prompts."
echo ""

# ── Generate SSH key if not exists ───────────────────────────
if [[ ! -f ~/.ssh/id_rsa ]]; then
    info "Generating SSH key pair..."
    ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N "" -q
    success "SSH key generated: ~/.ssh/id_rsa"
else
    success "SSH key already exists: ~/.ssh/id_rsa"
fi

# ── Need sshpass for password-based key push ─────────────────
if ! command -v sshpass &>/dev/null; then
    info "Installing sshpass..."
    sudo apt-get install -y sshpass -q
fi

# ── Get password if not set in lab.conf ──────────────────────
if [[ -z "$SSH_PASS" ]]; then
    read -s -p "Enter SSH password for $SSH_USER on student PCs: " SSH_PASS
    echo ""
fi

echo ""
info "Pushing SSH key to ${IP_PREFIX}.${IP_START} → ${IP_PREFIX}.${IP_END}..."
echo ""

PASS=0; FAIL=0; SKIP=0

TOTAL=$((IP_END - IP_START + 1))
for i in $(seq $IP_START $IP_END); do
    IP="${IP_PREFIX}.${i}"
    PC_NUM=$((i - IP_START + 1))
    PC_PAD=$(printf "%02d" "$PC_NUM")

    printf "  PC-%02d  %-16s  " "$PC_NUM" "($IP)"

    # Quick ping
    if ! ping -c1 -W2 "$IP" &>/dev/null; then
        echo -e "${YELLOW}offline — skipped${NC}"
        ((SKIP++))
        continue
    fi

    # Push key
    if sshpass -p "$SSH_PASS" ssh-copy-id \
        -o StrictHostKeyChecking=no \
        -o ConnectTimeout=6 \
        "$SSH_USER@$IP" &>/dev/null 2>&1; then
        echo -e "${GREEN}key installed ✓${NC}"
        ((PASS++))
    else
        echo -e "${RED}failed${NC}"
        ((FAIL++))
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "  ${GREEN}✓ Done   : $PASS / $TOTAL${NC}"
echo -e "  ${YELLOW}⏭ Skipped: $SKIP (offline)${NC}"
echo -e "  ${RED}✗ Failed : $FAIL${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  Now run:  ./3_deploy_all.sh"
echo "  (No passwords needed anymore.)"
echo ""
