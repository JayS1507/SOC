#!/bin/bash
# ============================================================
#  SOC Platform — SERVER SETUP   (Step 1 of 2)
#  Run this ONCE on the teacher/SOC machine.
#
#  What it does:
#    - Installs Python dependencies
#    - Sets server IP in config
#    - Opens firewall ports 9000 + 8000
#    - Creates systemd services (auto-start on boot)
#    - Starts manager + dashboard
#
#  Usage:
#    chmod +x 1_setup_server.sh
#    sudo ./1_setup_server.sh
# ============================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
source "$SCRIPT_DIR/lab.conf"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ "$EUID" -ne 0 ]] && error "Please run as root: sudo ./1_setup_server.sh"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║      SOC PLATFORM — SERVER SETUP (Step 1/2)     ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── Detect / confirm server IP ────────────────────────────────
DETECTED_IP=$(hostname -I | awk '{print $1}')
info "Detected server IP : $DETECTED_IP"
info "lab.conf SERVER_IP : $SERVER_IP"

if [[ "$DETECTED_IP" != "$SERVER_IP" ]]; then
    warn "IPs differ — using detected IP: $DETECTED_IP"
    warn "Edit lab.conf if this is wrong, then re-run."
    SERVER_IP="$DETECTED_IP"
fi

read -p "  Proceed with SERVER_IP=$SERVER_IP ? [Y/n]: " ok
[[ "$ok" =~ ^[Nn] ]] && { read -p "  Enter correct IP: " SERVER_IP; }
echo ""

# ── Python dependencies ───────────────────────────────────────
info "Installing Python dependencies..."
pip3 install fastapi uvicorn psutil watchdog --break-system-packages -q
success "Python deps installed"

# ── Update shared/config.py ───────────────────────────────────
CONFIG="$SOC_DIR/shared/config.py"
info "Setting MANAGER_HOST = $SERVER_IP in shared/config.py"
sed -i "s/MANAGER_HOST = \".*\"/MANAGER_HOST = \"$SERVER_IP\"/" "$CONFIG"
success "Config updated"

# ── Manager: listen on 0.0.0.0 so student PCs can connect ─────
MGMT_PY="$SOC_DIR/manager/manager.py"
if grep -q '"127.0.0.1", MANAGER_PORT' "$MGMT_PY"; then
    info "Configuring manager to listen on all interfaces..."
    sed -i 's/"127.0.0.1", MANAGER_PORT/"0.0.0.0", MANAGER_PORT/' "$MGMT_PY"
    success "Manager will accept LAN connections"
else
    success "Manager already configured for LAN"
fi

# ── Open firewall ports ───────────────────────────────────────
info "Opening firewall ports ${MANAGER_PORT} and ${DASHBOARD_PORT}..."
if command -v ufw &>/dev/null; then
    ufw allow ${MANAGER_PORT}/tcp comment "SOC-Manager"   &>/dev/null && success "Port ${MANAGER_PORT} open" || warn "ufw ${MANAGER_PORT} failed — check manually"
    ufw allow ${DASHBOARD_PORT}/tcp comment "SOC-Dashboard" &>/dev/null && success "Port ${DASHBOARD_PORT} open" || warn "ufw ${DASHBOARD_PORT} failed — check manually"
    ufw --force enable &>/dev/null || true
else
    iptables -I INPUT -p tcp --dport $MANAGER_PORT  -j ACCEPT 2>/dev/null || true
    iptables -I INPUT -p tcp --dport $DASHBOARD_PORT -j ACCEPT 2>/dev/null || true
    warn "ufw not found — used iptables (may not survive reboot)"
fi

# ── Systemd service: Manager ──────────────────────────────────
CURRENT_USER="${SUDO_USER:-$USER}"
info "Creating systemd service: soc-manager"
cat > /etc/systemd/system/soc-manager.service << SVCEOF
[Unit]
Description=SOC Platform Manager (port ${MANAGER_PORT})
After=network.target

[Service]
Type=simple
User=$CURRENT_USER
WorkingDirectory=$SOC_DIR
ExecStart=/usr/bin/python3 $SOC_DIR/manager/manager.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

# ── Systemd service: Dashboard ────────────────────────────────
info "Creating systemd service: soc-dashboard"
cat > /etc/systemd/system/soc-dashboard.service << SVCEOF
[Unit]
Description=SOC Platform Dashboard (port ${DASHBOARD_PORT})
After=network.target soc-manager.service

[Service]
Type=simple
User=$CURRENT_USER
WorkingDirectory=$SOC_DIR
ExecStart=/usr/bin/python3 $SOC_DIR/dashboard/api.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable soc-manager soc-dashboard
systemctl restart soc-manager soc-dashboard
success "Services started and enabled on boot"

sleep 3
echo ""
echo "  Service status:"
systemctl is-active soc-manager  &>/dev/null && \
    echo -e "  ${GREEN}✅ soc-manager  : RUNNING${NC}" || \
    echo -e "  ${RED}❌ soc-manager  : FAILED — run: journalctl -u soc-manager -n 30${NC}"
systemctl is-active soc-dashboard &>/dev/null && \
    echo -e "  ${GREEN}✅ soc-dashboard: RUNNING${NC}" || \
    echo -e "  ${RED}❌ soc-dashboard: FAILED — run: journalctl -u soc-dashboard -n 30${NC}"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║            SERVER SETUP COMPLETE ✓               ║"
echo "╠══════════════════════════════════════════════════╣"
printf "║  Manager    : %-35s║\n" "${SERVER_IP}:${MANAGER_PORT}"
printf "║  Dashboard  : %-35s║\n" "http://${SERVER_IP}:${DASHBOARD_PORT}"
echo "╠══════════════════════════════════════════════════╣"
echo "║  NEXT: Deploy agents to student PCs              ║"
echo "║                                                  ║"
echo "║  Option A — USB/walk-up (each PC manually):      ║"
echo "║    sudo ./2_install_agent.sh                     ║"
echo "║                                                  ║"
echo "║  Option B — SSH mass deploy (all 60 at once):    ║"
echo "║    ./0_setup_ssh_keys.sh   ← first time only     ║"
echo "║    ./3_deploy_all.sh                             ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
