#!/bin/bash
# ============================================================
#  SOC Platform — LAB STATUS CHECK
#  Shows all 60 agents: online/offline/never connected.
#  Run anytime from the server.
#
#  Usage:  ./4_check_status.sh
#  Live:   watch -n 10 ./4_check_status.sh
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/lab.conf"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; GRAY='\033[0;37m'; NC='\033[0m'

SERVER_IP_LOCAL=$(hostname -I | awk '{print $1}')
TOTAL=$((IP_END - IP_START + 1))

clear
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║          SOC PLATFORM — LAB STATUS                      ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Time: $(date '+%H:%M:%S')   Server: $SERVER_IP_LOCAL"
echo ""

# ── Server services ───────────────────────────────────────────
echo "  Services:"
systemctl is-active soc-manager  &>/dev/null && \
    echo -e "  ${GREEN}✅ soc-manager  RUNNING${NC}  (port $MANAGER_PORT)" || \
    echo -e "  ${RED}❌ soc-manager  STOPPED${NC}  → sudo systemctl start soc-manager"
systemctl is-active soc-dashboard &>/dev/null && \
    echo -e "  ${GREEN}✅ soc-dashboard RUNNING${NC}  → http://$SERVER_IP_LOCAL:$DASHBOARD_PORT" || \
    echo -e "  ${RED}❌ soc-dashboard STOPPED${NC}  → sudo systemctl start soc-dashboard"
echo ""

# ── Fetch agent status from API ───────────────────────────────
API_RESPONSE=$(curl -s --max-time 3 "http://localhost:$DASHBOARD_PORT/api/agents" 2>/dev/null || echo "[]")
# Parse: build "agent_id STATUS last_seen" lines
AGENT_DATA=$(echo "$API_RESPONSE" | python3 -c "
import sys, json
try:
    agents = json.load(sys.stdin)
    for a in agents:
        print(a.get('agent_id','?') + '|' + a.get('status','?') + '|' + str(a.get('last_seen',''))[:16])
except:
    pass
" 2>/dev/null || true)

# ── Agent table ───────────────────────────────────────────────
echo "  ┌───────────────────────────────────────────────────┐"
printf "  │  %-12s %-15s %-8s %-16s│\n" "AGENT" "HOSTNAME" "STATUS" "LAST SEEN"
echo "  ├───────────────────────────────────────────────────┤"

ONLINE=0; OFFLINE_COUNT=0; NEVER=0

for i in $(seq $IP_START $IP_END); do
    PC_NUM=$((i - IP_START + 1))
    PC_PAD=$(printf "%02d" "$PC_NUM")
    AGENT_ID="agent-${PC_PAD}"
    HOSTNAME="lab-pc-${PC_PAD}"

    ENTRY=$(echo "$AGENT_DATA" | grep "^${AGENT_ID}|" || true)

    if [[ -z "$ENTRY" ]]; then
        printf "  │  ${GRAY}%-12s %-15s %-8s %-16s${NC}│\n" \
            "$AGENT_ID" "$HOSTNAME" "NEVER" "not deployed"
        ((NEVER++))
    else
        STATUS=$(echo "$ENTRY" | cut -d'|' -f2)
        LASTSEEN=$(echo "$ENTRY" | cut -d'|' -f3 | sed 's/T/ /')
        if [[ "$STATUS" == "online" ]]; then
            printf "  │  ${GREEN}%-12s %-15s %-8s${NC} %-16s│\n" \
                "$AGENT_ID" "$HOSTNAME" "ONLINE" "$LASTSEEN"
            ((ONLINE++))
        else
            printf "  │  ${RED}%-12s %-15s %-8s${NC} %-16s│\n" \
                "$AGENT_ID" "$HOSTNAME" "OFFLINE" "$LASTSEEN"
            ((OFFLINE_COUNT++))
        fi
    fi
done

echo "  └───────────────────────────────────────────────────┘"
echo ""
echo -e "  ${GREEN}Online: $ONLINE${NC}  |  ${RED}Offline: $OFFLINE_COUNT${NC}  |  ${GRAY}Never: $NEVER${NC}  |  Total: $TOTAL"
echo ""
echo "  Tip: watch -n 10 ./4_check_status.sh   (auto-refresh every 10s)"
echo ""
